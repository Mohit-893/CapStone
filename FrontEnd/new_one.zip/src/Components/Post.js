import React from 'react';
import '../CSS/Post.css'

function Post(props) {
    return (
        <div className='messageScreen'>
            Kindly login or Signup to see Posts....
        </div>
    );
}

export default Post;